// NullGate playground — loads the Go detection engine as WebAssembly and drives
// the UI. Every scan runs locally; no payload ever leaves the browser.
'use strict';

// ── Attack corpus ──────────────────────────────────────────────────────────
// Mirrors internal/waf/scan.go so the browser demo and the server-side scanner
// report the same thing. `benign` entries must NOT be flagged — they measure
// false positives, which is the half of a WAF's accuracy that marketing skips.
const ATTACKS = [
  ['sqli', "' OR '1'='1' --"],
  ['sqli', '1 UNION SELECT username,password FROM users'],
  ['xss', '<script>document.cookie</script>'],
  ['xss', '<img src=x onerror=alert(1)>'],
  ['rce', ';cat /etc/passwd'],
  ['rce', '$(whoami)'],
  ['lfi', '../../../../etc/passwd'],
  ['lfi', 'php://filter/convert.base64-encode/resource=index'],
  ['ssrf', 'http://169.254.169.254/latest/meta-data/'],
  ['ssrf', 'http://127.0.0.1:8080/admin'],
  ['xxe', '<!DOCTYPE foo [<!ENTITY x SYSTEM "file:///etc/passwd">]>'],
  ['ssti', '{{7*7}}'],
  ['nosqli', '{"user":{"$ne":null}}'],
  ['deserialize', 'rO0ABXNy'],
  ['proto_pollution', '{"__proto__":{"admin":true}}'],
  ['crlf', '%0d%0aSet-Cookie: injected=1'],
  ['scanner', 'sqlmap/1.7'],
];

const BENIGN = [
  ['benign', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'],
  ['benign', 'search?q=how+to+bake+sourdough+bread'],
  ['benign', 'user@example.com'],
  ['benign', 'The union of two sets selects all members.'],
  ['benign', '/products/category/electronics?page=2&sort=price'],
];

const PRESETS = [
  { key: 'sqli', name: 'SQL injection', payload: "' OR '1'='1' --" },
  { key: 'xss', name: 'XSS', payload: '<img src=x onerror=alert(1)>' },
  { key: 'rce', name: 'Command injection', payload: ';cat /etc/passwd' },
  { key: 'lfi', name: 'Path traversal', payload: '../../../../etc/passwd' },
  { key: 'ssrf', name: 'SSRF (cloud metadata)', payload: 'http://169.254.169.254/latest/meta-data/' },
  { key: 'xxe', name: 'XXE', payload: '<!DOCTYPE foo [<!ENTITY x SYSTEM "file:///etc/passwd">]>' },
  { key: 'ssti', name: 'Template injection', payload: '{{7*7}}' },
  { key: 'nosqli', name: 'NoSQL injection', payload: '{"user":{"$ne":null}}' },
  { key: 'proto', name: 'Prototype pollution', payload: '{"__proto__":{"admin":true}}' },
  { key: 'crlf', name: 'CRLF injection', payload: '%0d%0aSet-Cookie: injected=1' },
  { key: 'encoded', name: 'Double-encoded XSS', payload: '%253Cscript%253Ealert(1)%253C%252Fscript%253E' },
  { key: 'b64', name: 'Base64-smuggled SQLi', payload: 'JyBPUiAnMSc9JzEnIC0t' },
  { key: 'comment', name: 'Comment-split SQLi', payload: 'un/**/ion sel/**/ect 1,2,3' },
  { key: 'unicode', name: 'Unicode-escaped XSS', payload: '\\u003cscript\\u003ealert(1)\\u003c/script\\u003e' },
  { key: 'scanner', name: 'Scanner fingerprint', payload: 'sqlmap/1.7' },
  { key: 'benign', name: 'Benign request', payload: 'search?q=how+to+bake+sourdough+bread' },
];

// ── i18n ───────────────────────────────────────────────────────────────────
const I18N = {
  ar: {
    'nav.playground': 'التجربة', 'nav.demo': 'عرض الهجمات', 'nav.deploy': 'النشر',
    'hero.title': 'جرّب جدار حماية حقيقي، من هنا',
    'hero.sub': 'محرك الكشف الفعلي في NullGate — نفس كود Go الذي يعمل في البروكسي — مُترجَم إلى WebAssembly ويعمل داخل متصفحك.',
    'hero.privacy': 'لا يُرسَل أي شيء. كل فحص يجري محليًا على جهازك.',
    'badge.rules': 'قاعدة كشف', 'badge.classes': 'فئة هجوم',
    'badge.selftest': 'كشف في الاختبار الذاتي', 'badge.install': 'تنصيب مطلوب',
    'pg.title': 'ساحة التجربة',
    'pg.sub': 'الصق أي حمولة — حقن SQL، ناقل XSS، محاولة تجاوز مُشفّرة — وشاهد قرار المحرك.',
    'pg.loading': 'جارٍ تحميل محرك الكشف…',
    'pg.label': 'حمولة الطلب',
    'pg.paranoia': 'مستوى التوجّس — الأعلى يكشف أكثر، مقابل إنذارات كاذبة',
    'pg.scan': 'افحص الحمولة',
    'pg.score': 'درجة الشذوذ', 'pg.rulesHit': 'القواعد المطابقة',
    'pg.activeRules': 'القواعد النشطة', 'pg.time': 'زمن الفحص',
    'pg.presets': 'نماذج هجوم بنقرة واحدة',
    'th.rule': 'القاعدة', 'th.category': 'الفئة', 'th.severity': 'الخطورة',
    'th.desc': 'الوصف', 'th.result': 'النتيجة', 'th.payload': 'الحمولة', 'th.score': 'الدرجة',
    'demo.title': 'عرض الهجمات الكامل',
    'demo.sub': 'أطلِق المجموعة كاملة — 17 هجومًا حقيقيًا مع حركة سليمة — وشاهد معدل الكشف وعدد الإنذارات الكاذبة.',
    'demo.run': 'شغّل عرض الهجمات',
    'kpi.total': 'حمولة مُطلَقة', 'kpi.blocked': 'هجوم محجوب', 'kpi.missed': 'هجوم فائت',
    'kpi.rate': 'معدل الكشف', 'kpi.fp': 'إنذار كاذب',
    'dep.title': 'حماية موقع حقيقي',
    'dep.sub': 'هذه الصفحة تشغّل محرك الكشف فقط. لتصفية حركة فعلية، يعمل NullGate كبروكسي عكسي أمام تطبيقك — بأمر واحد.',
    'dep.whyTitle': 'لماذا لا يستطيع الموقع نفسه حماية موقعي؟ ',
    'dep.whyBody': 'الجدار الناري يجب أن يقع في مسار الشبكة بين الزوار وسيرفرك ليفحص الطلبات ويحجبها. صفحة ويب لا تستطيع ذلك — فالمحرك هو ما تختبره هنا، والبروكسي هو ما تنشره هناك.',
    'dep.copy': 'نسخ',
    'dep.tlsIntro': 'على سيرفر له نطاق، يُصدر NullGate شهادة HTTPS بنفسه عبر Let’s Encrypt:',
    'foot.arch': 'المعمارية', 'foot.docs': 'التوثيق',
    'foot.note': 'NullGate WAF — محرك الكشف يعمل محليًا عبر WebAssembly.',
  },
};

let lang = 'en';
const EN_CACHE = {};

function applyLang(next) {
  lang = next;
  const isAr = next === 'ar';
  document.documentElement.lang = isAr ? 'ar' : 'en';
  document.documentElement.dir = isAr ? 'rtl' : 'ltr';
  document.getElementById('langBtn').textContent = isAr ? 'English' : 'العربية';

  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    if (EN_CACHE[key] === undefined) EN_CACHE[key] = el.textContent;
    el.textContent = isAr ? (I18N.ar[key] ?? EN_CACHE[key]) : EN_CACHE[key];
  });
  try { localStorage.setItem('ng-lang', next); } catch (_) {}
}

// ── Engine bootstrap ───────────────────────────────────────────────────────
const dot = document.getElementById('engineDot');
const statusEl = document.getElementById('engineStatus');
const scanBtn = document.getElementById('scanBtn');
const demoBtn = document.getElementById('demoBtn');

function setStatus(text, cls) {
  statusEl.textContent = text;
  dot.className = 'dot' + (cls ? ' ' + cls : '');
}

async function bootEngine() {
  if (typeof WebAssembly === 'undefined') {
    setStatus(lang === 'ar' ? 'متصفحك لا يدعم WebAssembly.' : 'This browser does not support WebAssembly.', 'fail');
    return;
  }
  try {
    const go = new Go();
    const resp = await fetch('wasm/nullgate.wasm');
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const bytes = await resp.arrayBuffer();
    const result = await WebAssembly.instantiate(bytes, go.importObject);
    go.run(result.instance);

    if (typeof nullgateScan !== 'function') throw new Error('engine did not register');
    const probe = JSON.parse(nullgateScan('', 2));
    document.getElementById('badgeRules').textContent = probe.total_rules;
    const kb = Math.round(bytes.byteLength / 1024);
    setStatus(
      (lang === 'ar'
        ? `المحرك جاهز — ${probe.total_rules} قاعدة مُجمّعة، ${kb} ك.ب، يعمل محليًا`
        : `Engine ready — ${probe.total_rules} rules compiled, ${kb} KB, running locally`),
      'ready'
    );
    scanBtn.disabled = false;
    demoBtn.disabled = false;
  } catch (err) {
    setStatus((lang === 'ar' ? 'فشل تحميل المحرك: ' : 'Engine failed to load: ') + err.message, 'fail');
  }
}

// ── Scanning ───────────────────────────────────────────────────────────────
// The engine reports matches and an anomaly score; the block decision is the
// same policy the proxy applies by default: any critical/high match is
// decisive, otherwise accumulated score must reach the threshold.
const ANOMALY_THRESHOLD = 8;

function decide(res) {
  if (!res.matches || res.matches.length === 0) return false;
  for (const m of res.matches) {
    if (m.severity >= 2) return true; // high(2) or critical(3)
  }
  return res.anomaly_score >= ANOMALY_THRESHOLD;
}

const SEV_NAME = ['low', 'medium', 'high', 'critical'];
const SEV_AR = { low: 'منخفضة', medium: 'متوسطة', high: 'عالية', critical: 'حرجة' };

function scan(payload, paranoia) {
  const t0 = performance.now();
  const res = JSON.parse(nullgateScan(payload, paranoia));
  res.ms = performance.now() - t0;
  res.blocked = decide(res);
  return res;
}

const paranoiaEl = document.getElementById('paranoia');
const paranoiaVal = document.getElementById('paranoiaVal');
const payloadEl = document.getElementById('payload');
const verdictEl = document.getElementById('verdict');

function runScan() {
  const payload = payloadEl.value;
  if (!payload.trim()) {
    payloadEl.focus();
    return;
  }
  const res = scan(payload, Number(paranoiaEl.value));
  const isAr = lang === 'ar';

  verdictEl.className = 'verdict show ' + (res.blocked ? 'blocked' : 'allowed');
  document.getElementById('verdictTag').textContent = res.blocked
    ? (isAr ? '⛔ محجوب' : '⛔ BLOCKED')
    : (isAr ? '✓ مسموح' : '✓ ALLOWED');
  document.getElementById('mScore').textContent = res.anomaly_score;
  document.getElementById('mRules').textContent = res.matches ? res.matches.length : 0;
  document.getElementById('mActive').textContent = res.rule_count;
  document.getElementById('mTime').textContent = res.ms.toFixed(2) + 'ms';

  const note = document.getElementById('verdictNote');
  if (res.blocked) {
    note.textContent = isAr
      ? 'كان NullGate سيرفض هذا الطلب بـ 403 قبل أن يصل إلى تطبيقك. لا يُكشَف للمهاجم أي تفاصيل عن القاعدة التي طابقت.'
      : 'NullGate would reject this request with a 403 before it reaches your app. The attacker is told nothing about which rule fired.';
  } else if (res.matches && res.matches.length) {
    note.textContent = isAr
      ? 'طابقت قواعد، لكن الدرجة المتراكمة لم تبلغ عتبة الحجب. ارفع مستوى التوجّس لتشديد القرار.'
      : 'Rules matched, but the accumulated score stayed under the block threshold. Raise the paranoia level to tighten this.';
  } else {
    note.textContent = isAr
      ? 'لم تُطابق أي قاعدة — يُمرَّر هذا الطلب إلى تطبيقك كحركة سليمة.'
      : 'No rule matched — this request passes through to your app as legitimate traffic.';
  }

  const wrap = document.getElementById('matchWrap');
  const body = document.getElementById('matchBody');
  body.textContent = '';
  if (res.matches && res.matches.length) {
    wrap.hidden = false;
    for (const m of res.matches) {
      const sev = SEV_NAME[m.severity] || 'low';
      const tr = document.createElement('tr');
      const cells = [m.rule_id, m.category, null, m.description];
      cells.forEach((val, i) => {
        const td = document.createElement('td');
        if (i === 2) {
          const span = document.createElement('span');
          span.className = 'sev sev-' + sev;
          span.textContent = isAr ? (SEV_AR[sev] || sev) : sev;
          td.appendChild(span);
        } else {
          td.textContent = val;
        }
        tr.appendChild(td);
      });
      body.appendChild(tr);
    }
  } else {
    wrap.hidden = true;
  }
}

// ── Demo runner ────────────────────────────────────────────────────────────
function runDemo() {
  const isAr = lang === 'ar';
  const paranoia = Number(paranoiaEl.value);
  const rows = [];
  let blocked = 0, missed = 0, fp = 0;

  for (const [cat, payload] of ATTACKS) {
    const res = scan(payload, paranoia);
    if (res.blocked) blocked++; else missed++;
    rows.push({ ok: res.blocked, cat, payload, score: res.anomaly_score, attack: true });
  }
  for (const [cat, payload] of BENIGN) {
    const res = scan(payload, paranoia);
    if (res.blocked) fp++;
    rows.push({ ok: !res.blocked, cat, payload, score: res.anomaly_score, attack: false });
  }

  document.getElementById('kTotal').textContent = ATTACKS.length + BENIGN.length;
  document.getElementById('kBlocked').textContent = blocked;
  document.getElementById('kMissed').textContent = missed;
  document.getElementById('kRate').textContent =
    Math.round((blocked / ATTACKS.length) * 100) + '%';
  document.getElementById('kFP').textContent = fp;

  const body = document.getElementById('demoBody');
  body.textContent = '';
  for (const r of rows) {
    const tr = document.createElement('tr');

    const tdResult = document.createElement('td');
    const tag = document.createElement('span');
    tag.className = 'sev ' + (r.ok ? 'sev-medium' : 'sev-critical');
    if (r.attack) {
      tag.textContent = r.ok ? (isAr ? '⛔ محجوب' : '⛔ blocked') : (isAr ? 'فائت' : 'missed');
    } else {
      tag.textContent = r.ok ? (isAr ? '✓ مُمرَّر' : '✓ passed') : (isAr ? 'إنذار كاذب' : 'false positive');
    }
    tdResult.appendChild(tag);
    tr.appendChild(tdResult);

    const tdCat = document.createElement('td');
    tdCat.textContent = r.attack ? r.cat : (isAr ? 'سليم' : 'benign');
    tr.appendChild(tdCat);

    const tdPayload = document.createElement('td');
    tdPayload.textContent = r.payload.length > 58 ? r.payload.slice(0, 58) + '…' : r.payload;
    tdPayload.style.direction = 'ltr';
    tr.appendChild(tdPayload);

    const tdScore = document.createElement('td');
    tdScore.textContent = r.score;
    tr.appendChild(tdScore);

    body.appendChild(tr);
  }
  document.getElementById('demoWrap').hidden = false;
}

// ── Wiring ─────────────────────────────────────────────────────────────────
const grid = document.getElementById('presetGrid');
for (const p of PRESETS) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'preset';
  const name = document.createElement('div');
  name.className = 'preset-name';
  name.textContent = p.name;
  const desc = document.createElement('div');
  desc.className = 'preset-desc';
  desc.textContent = p.payload.length > 26 ? p.payload.slice(0, 26) + '…' : p.payload;
  desc.style.direction = 'ltr';
  btn.append(name, desc);
  btn.addEventListener('click', () => {
    payloadEl.value = p.payload;
    if (!scanBtn.disabled) runScan();
    verdictEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
  grid.appendChild(btn);
}

paranoiaEl.addEventListener('input', () => {
  paranoiaVal.textContent = paranoiaEl.value;
  if (verdictEl.classList.contains('show') && payloadEl.value.trim()) runScan();
});
scanBtn.addEventListener('click', runScan);
demoBtn.addEventListener('click', runDemo);
payloadEl.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') runScan();
});

document.getElementById('langBtn').addEventListener('click', () => {
  applyLang(lang === 'ar' ? 'en' : 'ar');
  if (verdictEl.classList.contains('show')) runScan();
  if (!document.getElementById('demoWrap').hidden) runDemo();
});

document.querySelectorAll('[data-copy]').forEach(btn => {
  btn.addEventListener('click', async () => {
    const src = document.querySelector(btn.dataset.copy);
    try {
      await navigator.clipboard.writeText(src.textContent.trim());
      const original = btn.textContent;
      btn.textContent = lang === 'ar' ? 'تم النسخ ✓' : 'Copied ✓';
      setTimeout(() => { btn.textContent = original; }, 1600);
    } catch (_) {}
  });
});

// Preselect the language: an explicit saved choice wins, otherwise fall back to
// the browser's own preference so Arabic speakers land on Arabic.
let initial = (navigator.language || '').toLowerCase().startsWith('ar') ? 'ar' : 'en';
try {
  const saved = localStorage.getItem('ng-lang');
  if (saved === 'ar' || saved === 'en') initial = saved;
} catch (_) {}
applyLang(initial);
bootEngine();
