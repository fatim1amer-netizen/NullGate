package waf

import "testing"

// webAttacks mirrors the corpus shipped to the browser playground in
// web/assets/app.js. Keeping this test next to the engine means a rule change
// that would silently break the public demo fails CI instead.
var webAttacks = []struct{ cat, payload string }{
	{"sqli", "' OR '1'='1' --"},
	{"sqli", "1 UNION SELECT username,password FROM users"},
	{"xss", "<script>document.cookie</script>"},
	{"xss", "<img src=x onerror=alert(1)>"},
	{"rce", ";cat /etc/passwd"},
	{"rce", "$(whoami)"},
	{"lfi", "../../../../etc/passwd"},
	{"lfi", "php://filter/convert.base64-encode/resource=index"},
	{"ssrf", "http://169.254.169.254/latest/meta-data/"},
	{"ssrf", "http://127.0.0.1:8080/admin"},
	{"xxe", `<!DOCTYPE foo [<!ENTITY x SYSTEM "file:///etc/passwd">]>`},
	{"ssti", "{{7*7}}"},
	{"nosqli", `{"user":{"$ne":null}}`},
	{"deserialize", "rO0ABXNy"},
	{"proto_pollution", `{"__proto__":{"admin":true}}`},
	{"crlf", "%0d%0aSet-Cookie: injected=1"},
	{"scanner", "sqlmap/1.7"},
}

// webBenign are the "must not flag" samples in the playground. False positives
// are the half of WAF accuracy that is easy to hide, so assert on them.
var webBenign = []string{
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
	"search?q=how+to+bake+sourdough+bread",
	"user@example.com",
	"The union of two sets selects all members.",
	"/products/category/electronics?page=2&sort=price",
}

// webPresets are the one-click samples; the encoded ones prove the decoder
// chain still defeats the bypass techniques the demo advertises.
var webPresets = []struct{ name, payload string }{
	{"double-encoded xss", "%253Cscript%253Ealert(1)%253C%252Fscript%253E"},
	{"base64 sqli", "JyBPUiAnMSc9JzEnIC0t"},
	{"comment-split sqli", "un/**/ion sel/**/ect 1,2,3"},
	{"unicode-escaped xss", `<script>alert(1)</script>`},
}

// webScan reproduces exactly what cmd/wasm does: decode into variants, scan
// each, and aggregate. If this drifts from the wasm bridge the demo lies.
func webScan(t *testing.T, payload string, paranoia int) ScanResult {
	t.Helper()
	dec := NewDecoder(DecodingConfig{
		MaxDecodeDepth:       5,
		EnableBase64Scan:     true,
		EnableHexScan:        true,
		EnableUnicodeScan:    true,
		EnableCommentScan:    true,
		EnableWhitespaceScan: true,
	})
	eng := NewRuleEngine(paranoia, nil)

	var agg ScanResult
	seen := map[string]bool{}
	for _, v := range dec.Variants(payload) {
		res := eng.Scan(v)
		for _, m := range res.Matches {
			if !seen[m.RuleID] {
				seen[m.RuleID] = true
				agg.Matches = append(agg.Matches, m)
			}
		}
		if res.AnomalyScore > agg.AnomalyScore {
			agg.AnomalyScore = res.AnomalyScore
		}
		if res.HasCritical {
			agg.HasCritical = true
		}
	}
	return agg
}

// webBlocked applies the same decision the playground UI applies.
func webBlocked(sr ScanResult) bool {
	if len(sr.Matches) == 0 {
		return false
	}
	for _, m := range sr.Matches {
		if m.Severity >= SevHigh {
			return true
		}
	}
	return sr.AnomalyScore >= 8
}

func TestWebPlaygroundDetectsEveryAttack(t *testing.T) {
	for _, a := range webAttacks {
		if !webBlocked(webScan(t, a.payload, 2)) {
			t.Errorf("playground would MISS %s: %q", a.cat, a.payload)
		}
	}
}

func TestWebPlaygroundPassesBenign(t *testing.T) {
	for _, p := range webBenign {
		if webBlocked(webScan(t, p, 2)) {
			t.Errorf("playground false-positives on benign input: %q", p)
		}
	}
}

func TestWebPlaygroundDefeatsEncodedBypasses(t *testing.T) {
	for _, p := range webPresets {
		if !webBlocked(webScan(t, p.payload, 2)) {
			t.Errorf("playground would MISS %s: %q", p.name, p.payload)
		}
	}
}
