# NullGate Web Playground

Live, in-browser demo of the NullGate WAF detection engine. The exact same Go code that runs in the proxy — compiled to WebAssembly so visitors can scan payloads locally without installing anything.

## What's here

```
web/
├── index.html          # The playground UI (English + Arabic, auto-switches)
├── wasm/
│   └── nullgate.wasm   # The Go detection engine compiled to WASM (built from cmd/wasm/)
└── assets/
    ├── wasm_exec.js    # Go's WASM runtime bridge (from GOROOT)
    └── app.js          # Playground logic: loads WASM, drives UI, i18n
```

## How to build

From the repo root:

```bash
GOOS=js GOARCH=wasm go build -trimpath -ldflags="-s -w" -o web/wasm/nullgate.wasm ./cmd/wasm
```

The result: **~5.9 MB raw**, **~1.6 MB gzipped** (GitHub Pages serves it compressed).

## How to test locally

Any static HTTP server works. Python is the easiest:

```bash
cd web
python -m http.server 8000
# Then open http://localhost:8000
```

Or Node:

```bash
cd web
npx serve -p 8000
```

## How to deploy to GitHub Pages

1. **Commit the web/ directory**:
   ```bash
   git add web/
   git commit -m "Add WebAssembly playground for GitHub Pages"
   ```

2. **Push to GitHub**:
   ```bash
   git push origin master
   ```

3. **Enable GitHub Pages** in your repo settings:
   - Go to **Settings** → **Pages**
   - **Source**: Deploy from a branch
   - **Branch**: `master`
   - **Folder**: `/web`
   - Click **Save**

4. **Wait ~1 minute**. Your playground will be live at:
   ```
   https://<your-username>.github.io/NullGate/
   ```

## What visitors see

- **A live scanner**: paste a SQL injection, XSS payload, or encoded bypass attempt and watch the actual rule engine decide whether NullGate would block it.
- **Attack corpus demo**: fire 17 real attacks + 5 benign samples and see the detection rate and false-positive count.
- **One-click deploy instructions**: Docker Compose command and auto-TLS snippet so they can protect a real site.
- **Bilingual UI**: English and Arabic, auto-switched based on `navigator.language`, toggle with one click.
- **Zero backend**: everything runs in the browser. No payload ever leaves the machine.

## Why this works

NullGate's detection core (`internal/waf/rules.go` + `decoding.go`) is pure computation: regexp, string decoding, and scoring. No network I/O, no filesystem, no OS calls. That means it compiles cleanly to WebAssembly and runs at near-native speed in any modern browser.

The public playground is the same correctness gate CI uses — same corpus, same decision logic. If a rule change silently breaks the demo, `internal/waf/webcorpus_test.go` fails the build.

## Size note

The WASM binary pulls in `net/http`, `autocert`, and `yaml` because `internal/waf` imports them for the full server build. A pure detection-only build would be ~1 MB gzipped. The tradeoff: keeping one codebase means the playground is always in sync with the proxy, and 1.6 MB loads in <1 second on any connection.

## Maintenance

- **Update the attack corpus** in `web/assets/app.js` and `internal/waf/webcorpus_test.go` together. The test enforces they match.
- **Rebuild after rule changes**: `make wasm` (if you add that target to the Makefile), or the manual `go build` command above.
- **wasm_exec.js** is stable across Go releases, but if you upgrade Go, copy the new version from `$(go env GOROOT)/misc/wasm/wasm_exec.js`.
