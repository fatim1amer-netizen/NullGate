//go:build js && wasm

// Command wasm compiles NullGate's detection core to WebAssembly so the exact
// same rule engine and decoder that run in the proxy can also run inside a
// visitor's browser. Nothing is sent to a server: the payload is scanned
// locally, which is what lets the public playground be a static site.
package main

import (
	"encoding/json"
	"syscall/js"

	"nullgate/internal/waf"
)

func main() {
	c := make(chan struct{}, 0)

	// Expose scanPayload function to JavaScript
	js.Global().Set("nullgateScan", js.FuncOf(scanPayload))
	js.Global().Set("nullgateReady", js.ValueOf(true))

	<-c
}

// scanPayload is called from JavaScript with (payload, paranoia)
func scanPayload(this js.Value, args []js.Value) interface{} {
	if len(args) < 2 {
		return map[string]interface{}{
			"error": "missing arguments: expected (payload, paranoia)",
		}
	}

	payload := args[0].String()
	paranoia := args[1].Int()

	if paranoia < 1 {
		paranoia = 1
	}
	if paranoia > 4 {
		paranoia = 4
	}

	// Build decoder with sane defaults
	decoder := waf.NewDecoder(waf.DecodingConfig{
		MaxDecodeDepth:       5,
		EnableBase64Scan:     true,
		EnableHexScan:        true,
		EnableUnicodeScan:    true,
		EnableCommentScan:    true,
		EnableWhitespaceScan: true,
	})

	// Build rule engine
	engine := waf.NewRuleEngine(paranoia, nil)

	// Scan all variants
	var aggregateMatches []waf.MatchResult
	var aggregateScore int
	hasCritical := false

	for _, variant := range decoder.Variants(payload) {
		res := engine.Scan(variant)
		for _, m := range res.Matches {
			// Dedupe by rule ID
			found := false
			for _, existing := range aggregateMatches {
				if existing.RuleID == m.RuleID {
					found = true
					break
				}
			}
			if !found {
				aggregateMatches = append(aggregateMatches, m)
			}
		}
		if res.AnomalyScore > aggregateScore {
			aggregateScore = res.AnomalyScore
		}
		if res.HasCritical {
			hasCritical = true
		}
	}

	// Marshal to JSON
	result := map[string]interface{}{
		"matches":       aggregateMatches,
		"anomaly_score": aggregateScore,
		"has_critical":  hasCritical,
		"rule_count":    engine.RuleCount(),
		"total_rules":   engine.TotalRuleCount(),
		"paranoia":      paranoia,
	}

	jsonBytes, err := json.Marshal(result)
	if err != nil {
		return map[string]interface{}{
			"error": err.Error(),
		}
	}

	return js.ValueOf(string(jsonBytes))
}
