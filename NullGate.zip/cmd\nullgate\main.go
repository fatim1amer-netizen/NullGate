package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"nullgate/internal/waf"
)

const (
	Version = "2.0.0"
	Banner  = `
╔═══════════════════════════════════════════════════════════════════╗
║                     NullGate WAF — Security Gateway                ║
║   High-Performance Web Application Firewall • Fail-Closed Model    ║
║   Version: %-55s║
╚═══════════════════════════════════════════════════════════════════╝
`
)

func main() {
	var (
		configPath = flag.String("config", "configs/config.yaml", "Path to configuration file")
		showVer    = flag.Bool("version", false, "Show version information")
		runSelf    = flag.Bool("selftest", false, "Run the detection self-test and exit")
		genSecret  = flag.Bool("gen-secret", false, "Generate a random HMAC secret and exit")
		showConfig = flag.Bool("show-config", false, "Dump the effective configuration and exit")
		adminOn    = flag.Bool("admin", false, "Force-enable the admin dashboard on localhost (127.0.0.1:9091)")
		autoTLS    = flag.Bool("auto-tls", false, "Enable automatic HTTPS with Let's Encrypt (requires --domain)")
		domains    = flag.String("domain", "", "Comma-separated domain list for auto-TLS (e.g. example.com,www.example.com)")
	)
	flag.Parse()

	if *showVer {
		fmt.Printf("NullGate WAF v%s\n", Version)
		return
	}
	if *genSecret {
		fmt.Println(randomSecret(32))
		return
	}

	cfg, err := waf.LoadConfig(*configPath)
	if err != nil {
		log.Fatalf("failed to load configuration: %v", err)
	}

	// --admin is a convenience for local operators: enable the dashboard on the
	// loopback interface without editing the config file. It never opens the
	// admin surface to the network (require_localhost stays on).
	if *adminOn {
		cfg.Admin.Enabled = true
		if cfg.Admin.ListenAddr == "" {
			cfg.Admin.ListenAddr = "127.0.0.1:9091"
		}
		cfg.Admin.RequireLocalhost = true
	}

	// --auto-tls / --domain override the config for one-command HTTPS. The
	// operator points DNS at this host and NullGate provisions its own
	// Let's Encrypt certificate; no cert files to manage.
	if *autoTLS {
		cfg.Server.AutoTLS = true
	}
	if *domains != "" {
		cfg.Server.AutoTLSDomains = splitCSV(*domains)
	}

	// ── Cloud-platform auto-configuration (Render / Railway / Fly.io / etc.) ──
	// PaaS platforms inject a $PORT and expose exactly ONE port to the public
	// URL, terminating TLS at their edge. When $PORT is present we bind the
	// live control panel to it so the single public https:// URL opens the
	// dashboard directly — no localhost, no SSH tunnel. Secrets come from the
	// environment so nothing sensitive lives in the repo.
	if port := strings.TrimSpace(os.Getenv("PORT")); port != "" {
		cfg.Admin.Enabled = true
		cfg.Admin.ListenAddr = "0.0.0.0:" + port
		cfg.Admin.RequireLocalhost = false
		// Trust the platform's edge proxy for real client IPs.
		cfg.IP.TrustXForwardedFor = true
		log.Printf("cloud mode: control panel bound to public port %s", port)
	}
	// Allow the admin password hash + backend target to be overridden from the
	// environment so operators never commit real credentials.
	if h := strings.TrimSpace(os.Getenv("ADMIN_PASSWORD_HASH")); h != "" {
		cfg.Admin.PasswordHash = h
	}
	if p := strings.TrimSpace(os.Getenv("ADMIN_PASSWORD")); p != "" {
		cfg.Admin.PasswordHash = waf.HashPassword(p)
	}
	if b := strings.TrimSpace(os.Getenv("TARGET_BACKEND")); b != "" {
		cfg.Server.TargetBackend = b
	}

	if *runSelf {
		report := waf.RunSelfTest(cfg)
		fmt.Print(report.String())
		if report.FalseNegatives > 0 || report.FalsePositives > 0 {
			os.Exit(1)
		}
		return
	}
	if *showConfig {
		cfg.Print()
		return
	}

	fmt.Printf(Banner, Version)

	engine, err := waf.NewEngine(cfg)
	if err != nil {
		log.Fatalf("failed to initialize WAF engine: %v", err)
	}

	server := &http.Server{
		Addr:              cfg.Server.ListenAddr,
		Handler:           engine,
		ReadTimeout:       time.Duration(cfg.Server.ReadTimeout) * time.Second,
		ReadHeaderTimeout: time.Duration(cfg.Server.ReadHeaderTimeout) * time.Second,
		WriteTimeout:      time.Duration(cfg.Server.WriteTimeout) * time.Second,
		IdleTimeout:       time.Duration(cfg.Server.IdleTimeout) * time.Second,
		MaxHeaderBytes:    cfg.Server.MaxHeaderBytes,
	}

	// Wire the metrics endpoint and admin dashboard into the public listener
	// (metrics only; the dashboard gets its own socket when enabled).
	if cfg.Metrics.Enabled {
		metricsPath := cfg.Metrics.Path
		if metricsPath == "" {
			metricsPath = "/metrics"
		}
		mux := http.NewServeMux()
		mux.Handle(metricsPath, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
			fmt.Fprint(w, engine.Metrics().Prometheus())
		}))
		server.Handler = withMetrics(engine, mux)
	}

	// Separate admin socket: operational surface never shares the attack surface.
	if cfg.Admin.Enabled {
		admin := waf.NewAdminServer(
			cfg.Admin, cfg, engine.Metrics(), engine.Logger(), engine.Blocklist(),
			engine.Rules(), Version, engine.Rules().RuleCount(), engine.Rules().TotalRuleCount(),
		)
		adminServer := &http.Server{
			Addr:              cfg.Admin.ListenAddr,
			Handler:           admin.Handler(),
			ReadHeaderTimeout: 5 * time.Second,
			WriteTimeout:      10 * time.Second,
			IdleTimeout:       30 * time.Second,
		}
		go func() {
			log.Printf("admin dashboard listening on %s", cfg.Admin.ListenAddr)
			if err := adminServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				log.Printf("admin server error: %v", err)
			}
		}()
		defer adminServer.Close()
	}

	done := make(chan bool, 1)
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-quit
		log.Println("server is shutting down...")

		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()

		server.SetKeepAlivesEnabled(false)
		if err := server.Shutdown(ctx); err != nil {
			log.Printf("graceful shutdown failed: %v", err)
		}
		close(done)
	}()

	log.Printf("NullGate WAF v%s starting on %s", Version, cfg.Server.ListenAddr)
	log.Printf("proxying to backend: %s", cfg.Server.TargetBackend)
	log.Printf("paranoia level: %d, anomaly threshold: %d, rules active: %d/%d",
		cfg.Rules.ParanoiaLevel, cfg.Rules.AnomalyThreshold,
		engine.Rules().RuleCount(), engine.Rules().TotalRuleCount())
	log.Printf("fail-closed mode: ACTIVE")

	// Auto-TLS path: provision certificates from Let's Encrypt and start
	// listeners on :80 (ACME + redirect) and :443 (HTTPS). This takes over the
	// entire lifecycle, so it's an alternative to the manual TLS block below.
	if cfg.Server.AutoTLS {
		log.Printf("auto-TLS enabled for domains: %v", cfg.Server.AutoTLSDomains)
		if err := waf.StartAutoTLS(cfg, server.Handler); err != nil {
			log.Fatalf("auto-TLS failed: %v", err)
		}
		<-done
		log.Println("NullGate WAF stopped")
		return
	}

	if cfg.Server.EnableTLS {
		log.Printf("TLS enabled with certificate: %s", cfg.Server.TLSCert)
		if err := server.ListenAndServeTLS(cfg.Server.TLSCert, cfg.Server.TLSKey); err != nil && err != http.ErrServerClosed {
			log.Fatalf("could not start TLS server: %v", err)
		}
	} else {
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("could not start server: %v", err)
		}
	}

	<-done
	log.Println("NullGate WAF stopped")
}

// withMetrics wraps the engine handler so /metrics serves Prometheus output
// while everything else flows through the WAF pipeline.
func withMetrics(engine *waf.Engine, metricsMux *http.ServeMux) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/metrics") {
			metricsMux.ServeHTTP(w, r)
			return
		}
		engine.ServeHTTP(w, r)
	})
}

// randomSecret returns n cryptographically-random bytes hex-encoded.
func randomSecret(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return ""
	}
	return hex.EncodeToString(b)
}

// splitCSV splits a comma-separated string into a trimmed slice.
func splitCSV(s string) []string {
	if s == "" {
		return nil
	}
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}
